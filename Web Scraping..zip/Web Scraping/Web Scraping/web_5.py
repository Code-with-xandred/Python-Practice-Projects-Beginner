
import requests
from bs4 import BeautifulSoup
import csv

def Extract(url):
    response = requests.get(url=url).content
    # print(response)
    soup = BeautifulSoup(response , 'lxml')
    # tag = soup.div
    # print(tag)
    tag = soup.find('div' , {"id" : "mp-right"})
    # h = tag.find("h2").find("spam")
    h = tag.find_all("h2")
    # print(h)
    content = [ h2.text for h2 in h]
    # print(content)

    with open("wiki.csv", "w") as csv_file:
        csv_write = csv.writer(csv_file)
        csv_write.writerow(content)
    
Extract(url = "https://en.wikipedia.org/wiki/Main_Page")

