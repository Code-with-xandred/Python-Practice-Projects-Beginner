# import urllib.request , urllib.parse , urllib.error

# url = urllib.request.urlopen("http://127.0.0.1:8000/helloworld/")

# for line in url:
#     print(line.decode().strip())

# --------------------------------------------------------------------------------------------------

# import requests

# url = "http://127.0.0.1:8000/helloworld/"

# print(dir(requests))
# response = requests.get(url = url)
# print(response)
# print(dir(response))
# print(response.status_code)
# print(response.headers)
# print(response.request.headers)

# -----------------------------------------------------------------------------------------------------

# import requests

# url = "http://127.0.0.1:8000/helloworld/"

# user = {
#     "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36"
# }

# response = requests.get(url = url, headers = user)
# print(response.request.headers)
# print(response.content)
# print(type(response._content))

# -----------------------------------------------------------------------------------------------------

# import requests

# url = "http://127.0.0.1:8000/images/pr-super-megaforce.jpg"

# user = {
#     "user-agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36"
# }

# # response = requests.get(url = url, headers = user)
# # print(response.content)

# response = requests.get(url = url , headers = user)
# pic = response.content

# f = open("pr-super-megaforce.jpg" , "wb")


# f.write(pic)








