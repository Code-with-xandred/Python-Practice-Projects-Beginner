import requests

user = input("Enter The Image Name: ")

user_agent = {
    "User-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36"
}

url = f"https://www.google.com/search?sca_esv=be29cc62fc8e0244&sxsrf=AHTn8zp146WCUZNiCq4KdCzMQNo79DaIkA:1740139893369&q={user}&udm=2&fbs=ABzOT_CWdhQLP1FcmU5B0fn3xuWpA-dk4wpBWOGsoR7DG5zJBnsX62dbVmWR6QCQ5QEtPRqDwxy3B8GdFf-VpShv5jVGkEDtrghtvhb5IrGDE5cX4TvAeex5BMaBB5_PKNy-mumLvPSYNrRXAbpEkrD_1NzJsy8OaIIJWqpMsVnjHqCHrm7h2U_BydWj_v0TXP4X3hprncTQe6yTMABTxrL468JiqVW5Aw&sa=X&ved=2ahUKEwjUpNCh3tSLAxUoUvUHHcZYCS8QtKgLegQIERAB&cshid=1740140044943435&biw=1536&bih=695&dpr=1.25"

response = requests.get(url = url , headers = user_agent).content

print(response)

# --------------------------------------------------------------------------------------------------------------------

### 2 ###
import requests

user = input("Enter The Image Name: ")

user_agent = {
    "User-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36"
}

url = f"https://www.google.com/search?sca_esv=be29cc62fc8e0244&sxsrf=AHTn8zp146WCUZNiCq4KdCzMQNo79DaIkA:1740139893369&q={user}&udm=2&fbs=ABzOT_CWdhQLP1FcmU5B0fn3xuWpA-dk4wpBWOGsoR7DG5zJBnsX62dbVmWR6QCQ5QEtPRqDwxy3B8GdFf-VpShv5jVGkEDtrghtvhb5IrGDE5cX4TvAeex5BMaBB5_PKNy-mumLvPSYNrRXAbpEkrD_1NzJsy8OaIIJWqpMsVnjHqCHrm7h2U_BydWj_v0TXP4X3hprncTQe6yTMABTxrL468JiqVW5Aw&sa=X&ved=2ahUKEwjUpNCh3tSLAxUoUvUHHcZYCS8QtKgLegQIERAB&cshid=1740140044943435&biw=1536&bih=695&dpr=1.25"

response = requests.get(url = url , headers = user_agent).text

print(response)

# ----------------------------------------------------------------------------------------------------------------------------

## 3 ##
import requests
import re


user = input("Enter The Image Name: ")

user_agent = {
    "User-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36"
}

url = f"https://www.google.com/search?sca_esv=be29cc62fc8e0244&sxsrf=AHTn8zp146WCUZNiCq4KdCzMQNo79DaIkA:1740139893369&q={user}&udm=2&fbs=ABzOT_CWdhQLP1FcmU5B0fn3xuWpA-dk4wpBWOGsoR7DG5zJBnsX62dbVmWR6QCQ5QEtPRqDwxy3B8GdFf-VpShv5jVGkEDtrghtvhb5IrGDE5cX4TvAeex5BMaBB5_PKNy-mumLvPSYNrRXAbpEkrD_1NzJsy8OaIIJWqpMsVnjHqCHrm7h2U_BydWj_v0TXP4X3hprncTQe6yTMABTxrL468JiqVW5Aw&sa=X&ved=2ahUKEwjUpNCh3tSLAxUoUvUHHcZYCS8QtKgLegQIERAB&cshid=1740140044943435&biw=1536&bih=695&dpr=1.25"

response = requests.get(url = url , headers = user_agent).text

pattern = r"\[\"https://.*\.jpg\",[0-9]+,[0-9]+,[0-9]+\]"

images = re.findall(pattern , response)
print(images)
for image in images:
    print(image)

# -------------------------------------------------------------------------------------------------------------------------------------

## 4 ##


import requests
import re


user = input("Enter The Image Name: ")

user_agent = {
    "User-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36"
}

url = f"https://www.google.com/search?sca_esv=be29cc62fc8e0244&sxsrf=AHTn8zp146WCUZNiCq4KdCzMQNo79DaIkA:1740139893369&q={user}&udm=2&fbs=ABzOT_CWdhQLP1FcmU5B0fn3xuWpA-dk4wpBWOGsoR7DG5zJBnsX62dbVmWR6QCQ5QEtPRqDwxy3B8GdFf-VpShv5jVGkEDtrghtvhb5IrGDE5cX4TvAeex5BMaBB5_PKNy-mumLvPSYNrRXAbpEkrD_1NzJsy8OaIIJWqpMsVnjHqCHrm7h2U_BydWj_v0TXP4X3hprncTQe6yTMABTxrL468JiqVW5Aw&sa=X&ved=2ahUKEwjUpNCh3tSLAxUoUvUHHcZYCS8QtKgLegQIERAB&cshid=1740140044943435&biw=1536&bih=695&dpr=1.25"

response = requests.get(url = url , headers = user_agent).text

pattern = r"\[\"https://.*\.jpg\",[0-9]+,[0-9]+,[0-9]+\]"

images = re.findall(pattern , response)
print(images)

print(f"Total Images : {len(images)}")
no_of_images = int(input("Number Of Images To Be Dowloaded : "))

if images:
    for image in images[:no_of_images]:
        print(type(eval(image)))
        print(type(image))
        print(image)
        image_url = eval(image)[0]
        print(image_url)
        response = requests.get(url = image_url).content
        print(response)

# -------------------------------------------------------------------------------------------------------------------

## 5 ##

import requests
import re
import os


user = input("Enter The Image Name: ")

user_agent = {
    "User-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36"
}

url = f"https://www.google.com/search?sca_esv=be29cc62fc8e0244&sxsrf=AHTn8zp146WCUZNiCq4KdCzMQNo79DaIkA:1740139893369&q={user}&udm=2&fbs=ABzOT_CWdhQLP1FcmU5B0fn3xuWpA-dk4wpBWOGsoR7DG5zJBnsX62dbVmWR6QCQ5QEtPRqDwxy3B8GdFf-VpShv5jVGkEDtrghtvhb5IrGDE5cX4TvAeex5BMaBB5_PKNy-mumLvPSYNrRXAbpEkrD_1NzJsy8OaIIJWqpMsVnjHqCHrm7h2U_BydWj_v0TXP4X3hprncTQe6yTMABTxrL468JiqVW5Aw&sa=X&ved=2ahUKEwjUpNCh3tSLAxUoUvUHHcZYCS8QtKgLegQIERAB&cshid=1740140044943435&biw=1536&bih=695&dpr=1.25"

response = requests.get(url = url , headers = user_agent).text

pattern = r"\[\"https://.*\.jpg\",[0-9]+,[0-9]+,[0-9]+\]"

images = re.findall(pattern , response)
print(images)

print(f"Total Images : {len(images)}")
no_of_images = int(input("Number Of Images To Be Dowloaded : "))

if images:
    if not os.path.exists(user):
        os.mkdir(user)
        os.chdir(user)
    else:
        os.chdir(user)
    for image in images[:no_of_images]:
        image_url = eval(image)[0]
        response = requests.get(url = image_url).content
        image_name = image_url.split('/')[-1]

        with open(image_name , "wb") as file:
            file.write(response)
